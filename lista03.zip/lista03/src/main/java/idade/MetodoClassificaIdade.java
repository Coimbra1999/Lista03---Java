
package idade;

public class MetodoClassificaIdade {

    void classificaIdade(Integer idade){
              if(idade <= 2){
            System.out.println("Bebê");
        }else if(idade <= 11){
            System.out.println("Criança");
        }else if(idade <= 19){
            System.out.println("Adolescente");
        }else if(idade <= 30){
            System.out.println("Jovem");
        }else if(idade <= 60){
            System.out.println("Adulto");
        }else{
            System.out.println("Múmia");
        }
    }
}
/*
0 a 2 anos - “Bebê”
3 a 11 anos - “Criança”
12 a 19 anos - “Adolescente”
20 a 30 anos - “Jovem”
31 a 60 anos - “Adulto”
acima de 60 anos - “Idoso”.
*/
