
package idade;

import java.util.Scanner;

public class ClassificaIdade {
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        MetodoClassificaIdade classifica = new MetodoClassificaIdade();
        
        System.out.println("Informe a sua idade: ");
        Integer idade = in.nextInt();
        
        classifica.classificaIdade(idade);
    }
    
}
