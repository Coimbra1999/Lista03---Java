
package salarios;

public class MetodoClassesSociais {
    
    Double calcular(Double salario){
        Double resultado = salario/1045;
        return resultado;
    }
    
    String identificar(Double resultado){
    String classe;
        
    if (resultado <= 2){
        classe = "E";
    }else if (resultado < 4){
        classe = "D";
    }else if (resultado < 10){
        classe = "C";
    }else if (resultado < 20){
        classe = "B";
    }else{
        classe = "A";
    }
        return classe;
    }
}
