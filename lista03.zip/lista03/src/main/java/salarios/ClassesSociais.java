
package salarios;

import java.util.Scanner;

public class ClassesSociais {
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        MetodoClassesSociais calc = new MetodoClassesSociais();
        
        System.out.println("Informe sua renda mensal: ");
        Double salario = in.nextDouble();
        
        Double resultado = calc.calcular(salario);
        String classe = calc.identificar(resultado);
        
        System.out.printf("Sua renda mensal é equivalente a %d salários mínimos, portanto, sua classe social é %s",
                resultado.intValue(), classe);
    }
}
