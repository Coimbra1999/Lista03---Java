
package mediadasnotas;

import java.util.Scanner;

public class MediaDasNotas {
    
    public static void main(String[] args) {
        
        MetodoMedia calc = new MetodoMedia();
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe sua primeira nota: ");
        Double nota1 = in.nextDouble();
        
        System.out.println("Informe sua segunda nota: ");
        Double nota2 = in.nextDouble();
        
        System.out.println("Sua média é: " + calc.calcularMedia(nota1, nota2));
    }
    
}
