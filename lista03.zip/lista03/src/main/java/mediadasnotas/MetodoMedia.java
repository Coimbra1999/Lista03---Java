
package mediadasnotas;

public class MetodoMedia {
    
    Double calcularMedia(Double nota1, Double nota2){
        return (nota1*0.4) + (nota2*0.6);
    }
}
