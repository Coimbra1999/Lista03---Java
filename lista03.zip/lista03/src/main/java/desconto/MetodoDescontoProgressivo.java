
package desconto;

public class MetodoDescontoProgressivo {
    
    void exibirLinha(){
        System.out.println("-".repeat(30));
    }
    
    Integer calcularDesconto(Integer valor, Integer quantidade){
      
    }
    
    String exibirNotaFiscal(){
        System.out.println("Valor do produto: R$");
        System.out.println("Quantidade: ");
    }
}
