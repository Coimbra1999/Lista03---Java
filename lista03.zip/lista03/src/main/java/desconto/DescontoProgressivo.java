
package desconto;

import java.util.Scanner;

public class DescontoProgressivo {
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        MetodoDescontoProgressivo calc = new MetodoDescontoProgressivo();
        
        System.out.println("Bem vindo ao sistema de desconto progressivo!");
        
        System.out.println("Informe o valor unitário do produto: ");
        Integer valor = in.nextInt();
        
        System.out.println("Informe a quantidade: ");
        Integer quantidade = in.nextInt();
        
        calc.exibirLinha();
        calc.exibirLinha();
    }
}
